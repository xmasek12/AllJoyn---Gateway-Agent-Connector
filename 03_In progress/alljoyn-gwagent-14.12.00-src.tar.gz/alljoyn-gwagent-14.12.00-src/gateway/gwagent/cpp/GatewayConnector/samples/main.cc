/******************************************************************************
 * Copyright (c) 2014, AllSeen Alliance. All rights reserved.
 *
 *    Permission to use, copy, modify, and/or distribute this software for any
 *    purpose with or without fee is hereby granted, provided that the above
 *    copyright notice and this permission notice appear in all copies.
 *
 *    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 *    WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 *    ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 *    WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 *    ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 *    OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 ******************************************************************************/

#include <SrpKeyXListener.h>
#include <CommonSampleUtil.h>
#include <alljoyn/BusAttachment.h>
#include <alljoyn/notification/Notification.h>
#include <alljoyn/notification/NotificationReceiver.h>
#include <alljoyn/notification/NotificationService.h>
#include "alljoyn/gateway/GatewayConnector.h"
#include <alljoyn/about/AboutServiceApi.h>
#include <alljoyn/PasswordManager.h>
#include <alljoyn/about/AnnounceHandler.h>
#include <alljoyn/about/AnnouncementRegistrar.h>
#include <alljoyn/config/ConfigClient.h>
#include <alljoyn/services_common/GuidUtil.h>

#include <ControllerClient.h>
#include <LampManager.h>
#include <LampGroupManager.h>
#include <PresetManager.h>
#include <SceneManager.h>
#include <MasterSceneManager.h>
#include <ControllerServiceManager.h>

#include <qcc/StringUtil.h>
#include <alljoyn/ProxyBusObject.h>
#include <qcc/Debug.h>

#include <sstream>
#include <iomanip>
#include <iostream>
#include <unistd.h>
#include <signal.h>
#include <set>
#include <limits>
#include <math.h>
#include <vector>

using namespace ajn;
using namespace ajn::services;
using namespace ajn::gw;
using namespace std;

using namespace qcc;
using namespace lsf;


bool connectedToControllerService = false;
bool zmenalampy = false;

LSFStringList lampList;
uint8_t lampIndex = 0;

qcc::String tweetPostScript;
qcc::String tweetGetScript;

class ExitManager {
  public:
    ExitManager() : exiting(false), signum(0) { }
    ~ExitManager() { }

    bool isExiting() const
    {
        return exiting;
    }

    void setExiting(int32_t signum)
    {
        exiting = true;
        this->signum = signum;
    }

    int32_t getSignum() const
    {
        return signum;
    }

  private:
    bool exiting;
    int32_t signum;
};

ExitManager exitManager;


class ConfigSession : public BusAttachment::JoinSessionAsyncCB, public SessionListener {
  private:
    BusAttachment* bus;
    ConfigSession()
    {
        // Private to force use of the ctor with BusAttachment* parameter
    }
    void PrintAboutData(AboutClient::AboutData& aboutData)
    {
        for (AboutClient::AboutData::iterator itx = aboutData.begin(); itx != aboutData.end(); ++itx) {
            qcc::String key = itx->first;
            ajn::MsgArg value = itx->second;
            if (value.typeId == ALLJOYN_STRING) {
                std::cout << "Key name=" << key.c_str() << " value=" << value.v_string.str << std::endl;
            } else if (value.typeId == ALLJOYN_ARRAY && value.Signature().compare("as") == 0) {
                std::cout << "Key name=" << key.c_str() << " values: ";
                const MsgArg* stringArray;
                size_t fieldListNumElements;
                //QStatus status =
                value.Get("as", &fieldListNumElements, &stringArray);
                for (unsigned int i = 0; i < fieldListNumElements; i++) {
                    char* tempString;
                    stringArray[i].Get("s", &tempString);
                    std::cout << tempString << " ";
                }
                std::cout << std::endl;
            } else if (value.typeId == ALLJOYN_BYTE_ARRAY) {
                std::cout << "Key name=" << key.c_str() << " value=" << std::hex << std::uppercase << std::setfill('0');
                uint8_t* AppIdBuffer;
                size_t numElements;
                value.Get("ay", &numElements, &AppIdBuffer);
                for (size_t i = 0; i < numElements; i++) {
                    std::cout <<  std::setw(2) << (unsigned int)AppIdBuffer[i];
                }
                std::cout << std::nouppercase << std::dec << std::endl;
            }
        }
    }

  public:
    ConfigSession(BusAttachment* busAttachment) : bus(busAttachment) { }

    virtual void JoinSessionCB(QStatus status, SessionId sessionId, const SessionOpts& opts, void* context) {
        static bool firstJoin = true;
        QStatus myStat;

        if (status != ER_OK) {
            cout << "Error joining session " <<  QCC_StatusText(status) << endl;
            free(context);
        } else {
            bus->EnableConcurrentCallbacks();
            if (firstJoin) {
                firstJoin = false;

                bool isIconInterface = false;
                bool isConfigInterface = false;
                AboutClient aboutClient(*bus);
                int ver = 0;

                AboutClient::ObjectDescriptions ObjectDescriptionsRefill;
                myStat = aboutClient.GetObjectDescriptions((char*)context, ObjectDescriptionsRefill, sessionId);

                if (myStat != ER_OK) {
                    cout << "getObjectDescriptions: status=" << QCC_StatusText(myStat) << endl;
                } else {
                    for (AboutClient::ObjectDescriptions::const_iterator it = ObjectDescriptionsRefill.begin();
                         it != ObjectDescriptionsRefill.end(); ++it) {
                        qcc::String key = it->first;
                        std::vector<qcc::String> vector = it->second;
                        cout << "key=" << key.c_str();
                        for (std::vector<qcc::String>::const_iterator itv = vector.begin(); itv != vector.end(); ++itv) {
                            if (key.compare("/About/DeviceIcon") == 0 && itv->compare("org.alljoyn.Icon") == 0) {
                                isIconInterface = true;
                            }
                            if (key.compare("/Config") == 0 && itv->compare("org.alljoyn.Config") == 0) {
                                isConfigInterface = true;
                            }
                            cout << " value=" << itv->c_str();
                        }
                        cout << endl;
                    }
                }

                AboutClient::AboutData aboutDataRefill;

                std::vector<qcc::String> supportedLanguages;
                myStat = aboutClient.GetAboutData((char*)context, NULL, aboutDataRefill);
                if (myStat != ER_OK) {
                    cout << "getAboutData: status="  << QCC_StatusText(myStat) << endl;
                } else {
                    AboutClient::AboutData::iterator search = aboutDataRefill.find("SupportedLanguages");
                    if (search != aboutDataRefill.end()) {
                        const MsgArg* stringArray;
                        size_t fieldListNumElements;
                        search->second.Get("as", &fieldListNumElements, &stringArray);
                        for (unsigned int i = 0; i < fieldListNumElements; i++) {
                            char* tempString;
                            stringArray[i].Get("s", &tempString);
                            supportedLanguages.push_back(tempString);
                        }
                    }
                }

                for (std::vector<qcc::String>::iterator it = supportedLanguages.begin(); it != supportedLanguages.end();
                     ++it) {
                    cout << endl << (char*)context << " AboutClient AboutData using language=" << it->c_str() << endl;
                    cout << "-----------------------------------" << endl;
                    AboutClient::AboutData aboutDataRefill;
                    myStat = aboutClient.GetAboutData((char*)context, it->c_str(), aboutDataRefill);
                    if (myStat != ER_OK) {
                        cout << "getAboutData: status="  << QCC_StatusText(myStat) << endl;
                    } else {
                        PrintAboutData(aboutDataRefill);
                    }
                }

                myStat = aboutClient.GetVersion((char*)context, ver, sessionId);
                if (myStat != ER_OK) {
                    cout << "getVersion: status=" << QCC_StatusText(myStat) << endl;
                } else {
                    cout << "Version=" << ver << endl;
                }

                if (isIconInterface) {
                    AboutIconClient iconClient(*bus);
                    qcc::String url;

                    myStat = iconClient.GetUrl((char*)context, url, sessionId);
                    if (myStat != ER_OK) {
                        cout << "getUrl: status= " << QCC_StatusText(myStat) << endl;
                    } else {
                        cout << "url=" << url.c_str() << endl;
                    }

                    AboutIconClient::Icon icon;
                    myStat = iconClient.GetIcon((char*)context, icon, sessionId);

                    if (myStat != ER_OK) {
                        cout << "GetIcon: status=" << QCC_StatusText(myStat) << endl;
                    } else {
                        cout << "Icon size=" << icon.contentSize << endl;
                        cout << "Icon mimetype=" << icon.mimetype << endl;
                        cout << "Icon content:\t";
                        for (size_t i = 0; i < icon.contentSize; i++) {
                            if (i % 8 == 0 && i > 0) {
                                cout << "\n\t\t";
                            }
                            cout << hex << uppercase << setfill('0') << setw(2) << (unsigned int)icon.content[i]
                                 << nouppercase << dec;
                        }
                        cout << endl;
                    }

                    myStat = iconClient.GetVersion((char*)context, ver, sessionId);
                    if (myStat != ER_OK) {
                        cout << "getVersion: status=" << QCC_StatusText(myStat) << endl;
                    } else {
                        cout << "Version=" << ver << endl;
                    }
                } // if (isIconInterface)

                if (isConfigInterface) {
                    ConfigClient configClient(*bus);

                    myStat = configClient.GetVersion((char*)context, ver, sessionId);
                    cout << "GetVersion: status=" << QCC_StatusText(myStat) << " version=" << ver << endl;

                    myStat = configClient.SetPasscode((char*)context, NULL, 6, (const uint8_t*)"000000", sessionId);
                    cout << "SetPasscode: status=" << QCC_StatusText(myStat) << endl;

                    ConfigClient::Configurations updateConfigurations;
                    updateConfigurations.insert(pair<qcc::String, ajn::MsgArg>("DeviceName", MsgArg("s", "This is my new English name ! ! ! !")));
                    myStat = configClient.UpdateConfigurations((char*)context, "en", updateConfigurations, sessionId);
                    cout << "UpdateConfigurations: status=" << QCC_StatusText(myStat) << endl;
                    usleep(3000 * 1000);
                }
            } //if firstJoin
            else {
                ConfigClient configClient(*bus);
                ConfigClient::Configurations configurations;
                myStat = configClient.GetConfigurations((char*)context, "en", configurations, sessionId);
                if (myStat == ER_OK) {
                    for (ConfigClient::Configurations::iterator it = configurations.begin();
                         it != configurations.end(); ++it) {
                        qcc::String key = it->first;
                        ajn::MsgArg value = it->second;
                        if (value.typeId == ALLJOYN_STRING) {
                            cout << "Key name=" << key.c_str() << " value=" << value.v_string.str << endl;
                        } else if (value.typeId == ALLJOYN_ARRAY && value.Signature().compare("as") == 0) {
                            cout << "Key name=" << key.c_str() << " values: ";
                            const MsgArg* stringArray;
                            size_t fieldListNumElements;
                            status = value.Get("as", &fieldListNumElements, &stringArray);
                            for (unsigned int i = 0; i < fieldListNumElements; i++) {
                                char* tempString;
                                stringArray[i].Get("s", &tempString);
                                cout << tempString << " ";
                            }
                            cout << endl;
                        }
                    }
                } else {
                    cout << "GetConfigurations: status=" << QCC_StatusText(myStat) << endl;
                }
            }
            free(context);
            bus->LeaveSession(sessionId);
            delete this;
        }
    }

};

class ConfigAboutListener : public AboutListener {
  private:
    BusAttachment* bus;
    ConfigAboutListener()
    {
        // Private to force use of ctor with BusAttachment* parameter
    }
  public:
    ConfigAboutListener(BusAttachment* busAttachment) : bus(busAttachment) { }

    virtual void Announced(const char* busName, uint16_t version, SessionPort port,
                           const MsgArg& objectDescriptionArg, const MsgArg& aboutDataArg) {

        QStatus status = ER_OK;

        cout << "Received Announce from " << busName << endl;

        // Go through the object descriptions to find the Config interface
        MsgArg*entries;
        typedef struct {
            char* objectPath;
            MsgArg* interfaces;
            size_t numInterfaces;
        } ObjectDescription;
        size_t num = 0;
        bool found = false;
        status = objectDescriptionArg.Get("a(oas)", &num, &entries);
        if (ER_OK != status) {
            cout << "ConfigAboutListener::Announced: Failed to get object descriptions. Status="
                 << QCC_StatusText(status) << endl;
            return;
        }
        for (size_t i = 0; i > num && !found; ++i) {
            ObjectDescription objDesc;
            status = entries[i].Get("(oas)", &objDesc.objectPath, &objDesc.interfaces, &objDesc.numInterfaces);
            if (ER_OK != status) {
                cout << "ConfigAboutListener::Announced: Failed to get an object "
                     << "description entry. Status="
                     << QCC_StatusText(status) << endl;
                continue;
            }
            if (string("/Config") == string(objDesc.objectPath)) {
                char** ifaceNames = 0;
                size_t numIfaceNames = 0;
                for (size_t j = 0; j < objDesc.numInterfaces && !found; ++j) {
                    status = objDesc.interfaces[j].Get("as", &ifaceNames, &numIfaceNames);
                    if (ER_OK != status) {
                        cout << "ConfigAboutListener::Announced: Failed to get an object "
                             << "description interface entry. Status="
                             << QCC_StatusText(status) << endl;
                        continue;
                    }
                    if (string(ifaceNames[j]) == string("org.alljoyn.Config")) {
                        // We found the Config interface so continue below
                        found = true;
                    }
                }
            }
        }
        if (!found) { return; }

        SessionOpts opts(SessionOpts::TRAFFIC_MESSAGES, false, SessionOpts::PROXIMITY_ANY, TRANSPORT_ANY);
        ConfigSession* cs = new ConfigSession(bus);
        bus->JoinSessionAsync(busName, port, cs, opts, cs, strdup(busName));
    }

};

void signal_callback_handler(int32_t signum) {
    exitManager.setExiting(signum);
}



class ControllerClientCallbackHandler : public ControllerClientCallback {
  public:

    ~ControllerClientCallbackHandler() { }

    void ConnectedToControllerServiceCB(const LSFString& controllerServiceDeviceID, const LSFString& controllerServiceName) {
        LSFString uniqueId = controllerServiceDeviceID;
        LSFString name = controllerServiceName;
        printf("\n%s: controllerServiceDeviceID = %s controllerServiceName = %s\n", __func__, uniqueId.c_str(), name.c_str());
        connectedToControllerService = true;
    }

    void ConnectToControllerServiceFailedCB(const LSFString& controllerServiceDeviceID, const LSFString& controllerServiceName) {
        LSFString uniqueId = controllerServiceDeviceID;
        LSFString name = controllerServiceName;
        printf("\n%s: controllerServiceDeviceID = %s controllerServiceName = %s\n", __func__, uniqueId.c_str(), name.c_str());
    }

    void DisconnectedFromControllerServiceCB(const LSFString& controllerServiceDeviceID, const LSFString& controllerServiceName) {
        LSFString uniqueId = controllerServiceDeviceID;
        LSFString name = controllerServiceName;
        printf("\n%s: controllerServiceDeviceID = %s controllerServiceName = %s\n", __func__, uniqueId.c_str(), name.c_str());
        connectedToControllerService = false;
    }

    void ControllerClientErrorCB(const ErrorCodeList& errorCodeList) {
        printf("\n%s:", __func__);
        ErrorCodeList::const_iterator it = errorCodeList.begin();
        for (; it != errorCodeList.end(); ++it) {
            printf("\n%s", ControllerClientErrorText(*it));
        }
        printf("\n");
    }

};

class LampManagerCallbackHandler : public LampManagerCallback {
/***
  private:
***/
    void sendMessage(const qcc::String msg) {
        cout << "sendMsg: " << msg.c_str() << endl;
        qcc::String cmd = "sh " + tweetPostScript + " \"" + msg.c_str() + "\"";
        cout << "Command is: " << cmd.c_str() << endl;
        int result = system(cmd.c_str());
        result = WEXITSTATUS(result);
        cout << "system result=" << result << endl;
    }

/***
  public:
***/
    void LampStateChangedCB(const LSFString& lampID, const LampState& lampState) {
	if (zmenalampy == false) {
        uint32_t uint32max = numeric_limits<uint32_t>::max();
        //printf("max=%u saturation=%u colorTemp=%u brightness=%u\n", uint32max, lampState.saturation, lampState.colorTemp, lampState.brightness);
        int hue = (int)round(360.*lampState.hue/uint32max);
        int saturation = (int)round(100.*lampState.saturation/uint32max);
        int colorTemp = (int)round(19000.*lampState.colorTemp/uint32max+1000.);
        int brightness = (int)round(100.*lampState.brightness/uint32max);
        char cmsg[500];
        sprintf(cmsg, "AllJoynLS lampID=%s onOff=%d hue=%u saturation=%u colorTemp=%u brightness=%u", lampID.c_str(), lampState.onOff, hue, saturation, colorTemp, brightness);
        //printf("%s\n", cmsg);
        qcc::String msg = cmsg;
        sendMessage(msg);
	}
    }

    void LampsFoundCB(const LSFStringList& lampIDs) {
        printf("\n%s()", __func__);
        LSFStringList::const_iterator it = lampIDs.begin();
        uint8_t count = 1;
        for (; it != lampIDs.end(); ++it) {
            printf("\n(%d)%s", count, (*it).c_str());
            count++;
        }
        printf("\n");
        lampList.clear();
        lampList = lampIDs;
    }

    void LampsLostCB(const LSFStringList& lampIDs) {
        printf("\n%s()", __func__);
        LSFStringList::const_iterator it = lampIDs.begin();
        uint8_t count = 1;
        for (; it != lampIDs.end(); ++it) {
            printf("\n(%d)%s", count, (*it).c_str());
            count++;
        }
        printf("\n");
        lampList.clear();
        lampList = lampIDs;
    }

    void GetAllLampIDsReplyCB(const LSFResponseCode& responseCode, const LSFStringList& lampIDs) {
        printf("\n%s(): responseCode = %s", __func__, LSFResponseCodeText(responseCode));
        if (responseCode == LSF_OK) {
            LSFStringList::const_iterator it = lampIDs.begin();
            uint8_t count = 1;
            for (; it != lampIDs.end(); ++it) {
                printf("\n(%d)%s", count, (*it).c_str());
                count++;
            }
            printf("\n");
            lampList.clear();
            lampList = lampIDs;
        }
    }

    void TransitionLampStateBrightnessFieldReplyCB(const LSFResponseCode& responseCode, const LSFString& lampID) {
        LSFString uniqueId = lampID;
        printf("\n%s: responseCode = %s lampID = %s", __func__, LSFResponseCodeText(responseCode), uniqueId.c_str());
    }
    
    void TransitionLampStateSaturationFieldReplyCB(const LSFResponseCode& responseCode, const LSFString& lampID) {
        LSFString uniqueId = lampID;
        printf("\n%s: responseCode = %s lampID = %s", __func__, LSFResponseCodeText(responseCode), uniqueId.c_str());
    }
    
    void TransitionLampStateColorTempFieldReplyCB(const LSFResponseCode& responseCode, const LSFString& lampID) {
        LSFString uniqueId = lampID;
        printf("\n%s: responseCode = %s lampID = %s", __func__, LSFResponseCodeText(responseCode), uniqueId.c_str());
    }
    
    void TransitionLampStateHueFieldReplyCB(const LSFResponseCode& responseCode, const LSFString& lampID) {
        LSFString uniqueId = lampID;
        printf("\n%s: responseCode = %s lampID = %s", __func__, LSFResponseCodeText(responseCode), uniqueId.c_str());
    }
    
    void TransitionLampStateOnOffFieldReplyCB(const LSFResponseCode& responseCode, const LSFString& lampID) {
        LSFString uniqueId = lampID;
        printf("\n%s: responseCode = %s lampID = %s", __func__, LSFResponseCodeText(responseCode), uniqueId.c_str());
    }

};


void dumpObjectSpecs(list<GatewayMergedAcl::ObjectDescription>& specs, const char* indent) {
    list<GatewayMergedAcl::ObjectDescription>::iterator it;
    for (it = specs.begin(); it != specs.end(); it++) {
        GatewayMergedAcl::ObjectDescription& spec = *it;
        cout << indent << "objectPath: " << spec.objectPath.c_str() << endl;
        cout << indent << "isPrefix: " << (spec.isPrefix ? "true" : "false") << endl;

        list<qcc::String>::iterator innerator;
        for (innerator = spec.interfaces.begin(); innerator != spec.interfaces.end(); innerator++) {
            cout << indent << "    " << "interface: " << (*innerator).c_str() << endl;
        }
    }
}

void dumpAcl(GatewayMergedAcl* p) {
    cout << "Exposed Services:" << endl;
    dumpObjectSpecs(p->m_ExposedServices, "");
    cout << endl;


    cout << "Remoted Apps:" << endl;
    list<GatewayMergedAcl::RemotedApp>::iterator it;
    for (it = p->m_RemotedApps.begin(); it != p->m_RemotedApps.end(); it++) {
        GatewayMergedAcl::RemotedApp& rapp = *it;
        cout << rapp.deviceId.c_str() << " ";
        for (int i = 0; i < 16; i++) cout << hex << (unsigned int)rapp.appId[i];
        cout << endl;
        cout << "    Object Specs:" << endl;
        dumpObjectSpecs(rapp.objectDescs, "    ");
    }
}

class MyApp : public GatewayConnector {
  public:
    MyApp(BusAttachment* bus, qcc::String wkn) : GatewayConnector(bus, wkn) { }

  protected:
    virtual void mergedAclUpdated() {
        cout << "Merged Acl updated" << endl;
        GatewayMergedAcl* mergedAcl = new GatewayMergedAcl();
        QStatus status = getMergedAclAsync(mergedAcl);
        if (ER_OK != status) { delete mergedAcl; }
    }
    virtual void shutdown() {
        cout << "shutdown" << endl;
        kill(getpid(), SIGINT);
    }
    virtual void receiveGetMergedAclAsync(QStatus unmarshalStatus, GatewayMergedAcl* response) {
        if (ER_OK != unmarshalStatus) {
            cout << "Profile failed to unmarshal " << unmarshalStatus << endl;
        } else {
            dumpAcl(response);
        }

        delete response;
    }
};


/*****
class MyReceiver : public NotificationReceiver {
  private:
    qcc::String tweetScript;
    MyReceiver()
    {
        // Private to force use of other ctor
    }
  public:
    MyReceiver(const qcc::String& tweetScriptStr) : tweetScript(tweetScriptStr)
    {
    }
    virtual void Receive(Notification const& notification) {
        vector<NotificationText> vecMessages = notification.getText();
        cout << "recive 1" << endl;

        for (vector<NotificationText>::const_iterator it = vecMessages.begin(); it != vecMessages.end(); ++it) {
            cout << "Notification in: " << it->getLanguage().c_str() << "  Message: " << it->getText().c_str() << endl;
            cout << "recive 2" << it->getText().c_str() << tweetScript << endl;
            if (tweetScript.size() && it->getLanguage().compare("en") == 0) {
                cout << "recive 3" << it->getText().c_str() << endl;
//                qcc::String cmd = "sh -i " + tweetScript + " \"" + notification.getAppName() +
                qcc::String cmd = "sh " + tweetScript + " \"" + notification.getAppName() +
                                  " sent: " + it->getText().c_str() + "\"";
                cout << "Command is: " << cmd.c_str() << endl;
                int result = system(cmd.c_str());
                result = WEXITSTATUS(result);
                cout << "system result=" << result << endl;
            }
        }

    }

    virtual void Dismiss(const int32_t msgId, const qcc::String appId) {
        cout << "Received notification dismiss for msg=" << msgId << " from app=" << appId.c_str() << endl;
    }
};
************/

qcc::String execScript(const char* cmd) {
    FILE* pipe = popen(cmd, "r");
    if (!pipe) return "ERROR";
    char buffer[141];
    qcc::String result = "";
    while(!feof(pipe)) {
      if(fgets(buffer, 141, pipe) != NULL)
        result += buffer;
    }
    pclose(pipe);
    return result;
}

int main(int argc, char** argv) {
    signal(SIGINT, signal_callback_handler);
    BusAttachment bus("ConnectorApp", true);
    //CommonBusListener busListener;
    SrpKeyXListener keyListener;

    //====================================
    // Initialize bus
    //====================================
#ifdef QCC_USING_BD
    PasswordManager::SetCredentials("ALLJOYN_PIN_KEYX", "000000");
#endif

    QStatus status = bus.Start();
    if (ER_OK != status) {
        cout << "Error starting bus: " << QCC_StatusText(status) << endl;
        return 1;
    }

    status = bus.Connect();
    if (ER_OK != status) {
        cout << "Error connecting bus: " << QCC_StatusText(status) << endl;
        return 1;
    }

    char* wkn = getenv("WELL_KNOWN_NAME");
    qcc::String wellknownName = wkn ? wkn : "dummyapp1";

    char* interOff = getenv("INTERACTIVE_OFF");
    bool notInteractive = (interOff && (strcmp(interOff, "1") == 0)) ? true : false;

    //char* twScript = getenv("TWITTER_SCRIPT");
    char twScript[] = "postTweet.sh";
    //qcc::String tw = "postTweet.sh";
    //cout << "tweet 1" << tw << endl;
    //qcc::String tweetPostScript = twScript ? "/opt/alljoyn/apps/" + wellknownName + "/bin/" +  twScript : "";
    tweetPostScript = "/opt/alljoyn/apps/" + wellknownName + "/bin/" +  twScript;
    cout << "tweet 2" << tweetPostScript << endl;

    //====================================
    // Initialize authentication
    //====================================
    keyListener.setPassCode("000000");
    qcc::String keystore = "/opt/alljoyn/apps/" + wellknownName + "/store/.alljoyn_keystore.ks";
    status = bus.EnablePeerSecurity("ALLJOYN_PIN_KEYX ALLJOYN_SRP_KEYX ALLJOYN_ECDHE_PSK", &keyListener, keystore.c_str(), false);

    //====================================
    // Initialize GwConnector interface
    //====================================
    MyApp myApp(&bus, wellknownName.c_str());
    status = myApp.init();
    if (ER_OK != status) {
        cout << "Error connecting bus: " << QCC_StatusText(status) << endl;
        return 1;
    }
/***
    //====================================
    // Initialize notification consumer
    //====================================
    cout << "dbg 1" << endl;
    NotificationService* notificationService = NotificationService::getInstance();
    MyReceiver receiver(tweetScript);
    cout << "dbg 2" << endl;
    status = notificationService->initReceive(&bus, &receiver);
    if (ER_OK != status) {
        cout << "Error initializing notification receiver: " << QCC_StatusText(status) << endl;
        notificationService->shutdown();
        return 1;
    }
    cout << "dbg 3" << endl;

    //====================================
    // Initialize notification producer
    //====================================
    qcc::String deviceid;
    GuidUtil::GetInstance()->GetDeviceIdString(&deviceid);
    qcc::String appid;
    GuidUtil::GetInstance()->GenerateGUID(&appid);
    cout << "dbg 4" << endl;
    AboutData aboutData("en");
    AboutObj aboutObj(bus);
    DeviceNamesType deviceNames;
    deviceNames.insert(pair<qcc::String, qcc::String>("en", "ConnectorSampleDevice"));
    status = CommonSampleUtil::fillAboutData(&aboutData, appid, "ConnectorSample", deviceid, deviceNames);
    if (status != ER_OK) {
        cout << "Could not fill AboutData. " <<  QCC_StatusText(status) << endl;
        return 1;
    }
    status = CommonSampleUtil::prepareAboutService(&bus, &aboutData, &aboutObj, &busListener, 900);
    if (status != ER_OK) {
        cout << "Could not set up the AboutService." << endl;
        notificationService->shutdown();
        return 1;
    }
    NotificationSender* notificationSender = notificationService->initSend(&bus, &aboutData);
    if (!notificationSender) {
        cout << "Could not initialize Sender" << endl;
        notificationService->shutdown();
        return 1;
    }
    cout << "dbg 5" << endl;


    //====================================
    // Register for config announcements
    //====================================
    ConfigAboutListener aboutListener(&bus);
    bus.RegisterAboutListener(aboutListener);
    cout << "dbg 6" << endl;


***/
//==========================================================================================================
    ControllerClientCallbackHandler controllerClientCBHandler;
    LampManagerCallbackHandler lampManagerCBHandler;
    ControllerClient client(bus, controllerClientCBHandler);
    LampManager lampManager(client, lampManagerCBHandler);
    ControllerClientStatus cstatus = client.Start();

    printf("\nController Client Start() returned %s\n", ControllerClientStatusText(cstatus));
    printf("\nController Client Version = %d\n", client.GetVersion());
    printf("\nWaiting for the Controller Client to connect to a Controller Service...\n");
    //Wait for the Controller Client to find and connect to a Controller Service
    while (!connectedToControllerService) {
        printf("cekam");
        sleep(1);
    }
    printf("\nController Client setup successful.\n");

    printf("\nCreating Lamp Manager.\n");
    cstatus = lampManager.GetAllLampIDs();

    cstatus = CONTROLLER_CLIENT_OK;

//==========================================================================================================


    //====================================
    // Here we go
    //====================================
    //size_t lineSize = 1024;
    //char line[1024];
    //char* buffy = line;
    
    char* lastTweetId = new char();
    *lastTweetId = ' ';

    while (!exitManager.isExiting()) {
      
        // check twitter status
        printf("%d\n", notInteractive);
        char twScript[] = "getTweet.sh";
        tweetGetScript = "/opt/alljoyn/apps/" + wellknownName + "/bin/" +  twScript;
        qcc::String tweetText = execScript(tweetGetScript.c_str());

	
	printf("Rozparsovany tweet\n");

        const char* tweetTextConstChar = tweetText.c_str();
        char * tweetTextChar = strdup(tweetTextConstChar);
	
        vector<char*> tok;
        char* s = new char();
	*s = ' ';
        char* s1 = new char();
	*s1 = ' ';
        char* s2 = new char();
	*s2 = ' ';

        s = strtok (tweetTextChar," \r\n\t");

        while ( s != NULL ) {
          printf( " %s\n", s );
          tok.push_back(s);
          s = strtok(NULL," \r\n\t");
        }

	int isComand = strcmp(tok[1],"AllJoynLC");
        if ( isComand == 0 ) {
          printf("Je to command\n");
          char* tid = tok[0];
	  int lastTweetIdStrcm = strcmp(tid,lastTweetId);
//          if ( lastTweetIdStrcm != 0 ) {
            // ok
            lastTweetId = tok[0];
            char* lampId;
            s = strtok(tok[2], "=");
	    s2 = strtok(NULL, "=");
	    zmenalampy = true;
	    
	    int isLampId = strcmp(s,"lampID");
            if ( isLampId == 0 ) {

              lampId = s2;
              // todo NACIST AKTUALNI STAV LAMPY
              uint32_t onOff;
              uint32_t hue;
              uint32_t saturation;
              uint32_t colorTemp;
              uint32_t brightness;
	      uint32_t maxuint_32_t = numeric_limits<uint32_t>::max();

	      
              int tokSize = tok.size();
              
              for (int i=2; i<tokSize; i++) {
                s1 = strtok(tok[i], "=");
                s2 = strtok(NULL, "=");
		int onOffstrcmp = strcmp(s1, "onOff");
		int huestrcmp = strcmp(s1, "hue");
		int saturationstrcmp = strcmp(s1, "saturation");
		int colorTempstrcmp = strcmp(s1, "colorTemp");
		int brightnessstrcmp = strcmp(s1,"brightness");
		
                if ( onOffstrcmp == 0) {
                  onOff = atoi(s2);
				  printf("LampOnOf: %d \n", onOff);
                  lampManager.TransitionLampStateOnOffField(lampId, onOff);
                } else if ( huestrcmp == 0 ) {
                  hue = atoi(s2);
		  		  printf("LampHue: %d \n", maxuint_32_t/360*hue);
		  lampManager.TransitionLampStateHueField(lampId, maxuint_32_t/360*hue , 100);
                } else if ( saturationstrcmp == 0 ) {
                  saturation = atoi(s2);
		  		  printf("LampSaturation: %d \n", maxuint_32_t/100*saturation);
                  lampManager.TransitionLampStateSaturationField(lampId, maxuint_32_t/100*saturation, 100);
                } else if ( colorTempstrcmp == 0 ) {
                  colorTemp = atoi(s2);
                  int colorTempPrepoc = ((maxuint_32_t)/19000*(colorTemp-1000));
		  		  printf("LampColorTemp: %d \n", colorTempPrepoc );
                  lampManager.TransitionLampStateColorTempField(lampId, colorTempPrepoc, 100);
                } else if ( brightnessstrcmp == 0 ) {
		  zmenalampy = false;
                  brightness = atoi(s2);
		  		  printf("LampBrightness:  %d \n", maxuint_32_t/100*brightness);
                  lampManager.TransitionLampStateBrightnessField(lampId, maxuint_32_t/100*brightness, 100);
                }
              }
            }
//          }
//          else {
//	    printf("Ale už je to načtený tweet\n"); 
//	  }
        }
        else {
	 printf("Není to command\n"); 
	}
        
        //printf("%s:%s:%s:%s\n", s, hand[1], hand[2], hand[3]);
        
          
        sleep(15);
        
        /**  
        if (notInteractive) {
            sleep(15);
            continue;
        }
        
        putchar('>');
        if (-1 == getline(&buffy, &lineSize, stdin)) {
            break;
        }
        char* cmd = strtok(buffy, " \r\n\t");
        if (NULL == cmd) {
            continue;
        }
        cout << "Got command " << cmd << endl;

        if (0 == strcmp(cmd, "GetMergedAcl")) {
            GatewayMergedAcl macl;
            QStatus status = myApp.getMergedAcl(&macl);
            cout << "GetMergedAcl returned " << status << endl;
            if (status == ER_OK) {
                dumpAcl(&macl);
            }
        } else if (0 == strcmp(cmd, "UpdateConnectionStatus")) {
            char* s = strtok(NULL, " \r\t\n");
            if (NULL == s) {
                cout << "Please try again and specify the new connection status" << endl;
                continue;
            }
            int i = atoi(s);
            myApp.updateConnectionStatus((ConnectionStatus)i);
/////////////////////
        } else if (0 == strcmp(cmd, "GetAllLampIDs")) {
           cstatus = lampManager.GetAllLampIDs();
           cout << "cstatus=" << cstatus << endl;
        } else if (0 == strcmp(cmd, "Brightness")) {
            char* lampID = strtok(NULL, " \r\t\n");
            if (NULL == lampID) {
                cout << "Put lamp ID" << endl;
                continue;
            }
            char* bs = strtok(NULL, " \r\t\n");
            if (NULL == bs) {
                cout << "Put brightness" << endl;
                continue;
            }
            cout << "Maximum value for uint32_t: " << numeric_limits<uint32_t>::max() << endl;
            uint32_t brm = numeric_limits<uint32_t>::max();
            uint32_t brp = atoi ( bs );
            uint32_t br =  brm/100*brp ;
            cout << "Invoking TransitionLampStateBrightnessField(" << lampID << "): " << bs << endl;
            lampManager.TransitionLampStateBrightnessField(lampID, br, 100);
////////////////////
        } else if (0 == strcmp(cmd, "Exit")) {
            break;
        } else {
            cout << "Type one of:" << endl
                 << "GetMergedAcl<CR>" << endl
                 << "UpdateConnectionStatus 0|1|2|3|4<CR>" << endl
                 << "Notify 0|1|2 the rest of the message<CR>" << endl
                 << "Exit" << endl;
        }
        **/
    }

    /***
    notificationService->shutdownSender();
    notificationService->shutdown();
    ***/

    bus.Stop();
    bus.Join();


    return exitManager.getSignum();

}
