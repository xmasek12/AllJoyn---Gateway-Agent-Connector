/******************************************************************************
 * Copyright (c) 2014, AllSeen Alliance. All rights reserved.
 *
 *    Permission to use, copy, modify, and/or distribute this software for any
 *    purpose with or without fee is hereby granted, provided that the above
 *    copyright notice and this permission notice appear in all copies.
 *
 *    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 *    WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 *    ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 *    WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 *    ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 *    OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 ******************************************************************************/

#import "ConnectorAppInfoAclsTableViewCell.h"
#import "alljoyn/gateway/AJGWCEnums.h"
#import "AJNStatus.h"

@implementation ConnectorAppInfoAclsTableViewCell

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)aclActiveSwitchValueChanged:(id)sender {

    QStatus status = ER_FAIL;
    AJGWCAclResponseCode resCode;

    if ([sender isOn])
    {
        //call Activate
        status = [self.aclObject activateUsingSessionId:self.sessionId aclResponseCode:resCode];
    } else {
        status = [self.aclObject deactivateUsingSessionId:self.sessionId aclResponseCode:resCode];
        //call deactivate
    }

    if (ER_OK != status || resCode != GW_ACL_RC_SUCCESS) {
        NSLog(@"Failed to change acl state. status:%@ responseCode:%@", [AJNStatus descriptionForStatusCode:status], [AJGWCEnums AJGWCAclResponseCodeToString:resCode]);

        [[[UIAlertView alloc] initWithTitle:@"Error" message:@"Failed to change acl state." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil] show];

        [sender setOn:![sender isOn] ];
    }
}
@end
