Welcome to AllJoyn Lighting Service Framework
==============================================

Please refer to the top level README.txt for details on building the code and running the end-to-end test.

Note: All the test programs contained in this directory are intended for use by the core Dev team for developer verification of the various LSF 
features. They have been opensourced on an AS-IS basis and bugs filed against them will not be supported.